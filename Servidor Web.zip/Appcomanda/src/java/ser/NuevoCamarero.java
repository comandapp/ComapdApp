/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ser;

import GestorBD.ServiciosAppComanda;
import Objetos.Bar;
import Objetos.Camarero;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Jonatan
 */
public class NuevoCamarero extends HttpServlet {
    private ServiciosAppComanda sac = new ServiciosAppComanda();
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet NuevoCamarero</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet NuevoCamarero at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {
            out.close();
        }
    }
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        boolean error = false;
        
        req.setCharacterEncoding("UTF-8");
        String nombre = req.getParameter("nombre");
        String apellido = req.getParameter("apellido");
        String nick = req.getParameter("nick");
        String pwd = req.getParameter("pwd");
        String rpwd = req.getParameter("rpwd");
        System.out.println("nombre"+nombre+apellido+nick);
        List <Camarero> lc = null;
        if (nombre.equals("")){
            error=true;
        }else if (apellido.equals("")){
            error=true;
        }else if (nick.equals("")){
            error=true;
        }else if (pwd.equals("")){
            error=true;
        }else if(rpwd.equals("")){
            error=true;
        }
        if (!error){
            if (pwd.equals(rpwd)){
                int i = 0;
                HttpSession sesion = req.getSession();
                Bar b = (Bar) sesion.getAttribute("bar");
                lc = sac.listaCamareroBar(b.getId());
                System.out.println("tamaño"+ lc.size());
                while (lc.size()>i){
                    lc.get(i).escribir();
                    if (lc.get(i).getNick().equals(nick)){
                        error=true;
                    }
                    i++;   
                }
                if (!error){
                    int identificador = 0;
                    if (lc.size()>0){
                        identificador = lc.get(lc.size()-1).getId();
                    }
                    sac.insertarCamarero(identificador+1, nombre, apellido, pwd, nick, b.getId());
                    mostrar(resp,"El camarero ha sido añadido con existo");
                    return;
                }else{
                    mostrar(resp,"El nick ya esta");
                    return;
                }
            }else{
                mostrar(resp,"Las contraseñas son distintas");
                return;
            }
        }else{
            mostrar(resp,"Hay alguna casilla en blanco");
            return;
        } 
    }
    private void mostrar(HttpServletResponse resp, String cadena){
        PrintWriter out;
        try {
            out = resp.getWriter();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("< meta content=\"text/html; charset=utf-8 />");
            out.println("<title>Logueo de Bar</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>"+cadena+"</h1>");
            out.println("</body>");
            out.println("</html>");
        } catch (IOException ex) {
            Logger.getLogger(NuevoBar.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
