/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ser;

import GestorBD.ServiciosAppComanda;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Jonatan
 */
public class NuevoUsuario extends HttpServlet {
    private ServiciosAppComanda sac = new ServiciosAppComanda();
    
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {        
        req.setCharacterEncoding("UTF-8");
        
        String nombre = req.getParameter("nombre");
        String apellido = req.getParameter("apellido");
        String nick = req.getParameter("nick");
        String direccion = req.getParameter("direccion");
        String tfno = req.getParameter("tfno");
        String provincia = req.getParameter("provincia");
        String municipio = req.getParameter("municipio");
        String email = req.getParameter("email");
        String pwd = req.getParameter("pwd");
        String rpwd = req.getParameter("rpwd");        
        String cuenta = req.getParameter("cuenta");
        
         Boolean error= false;
        if (nombre.equals("")){
            error = true;
        }else if (direccion.equals("")){
            error=true;
        }else if (tfno.equals("")){
            error=true;
        }else if (nick.equals("")){
            error=true;
        }else if (nick.length()>49){
            error=true;
        }else if (apellido.equals("")){
            error=true;
        }else if (provincia.equals("")){
            error=true;
        }else if (municipio.equals("")){
            error=true;
        }else if (email.equals("")){
            error=true;
        }else if (pwd.equals("")){
            error=true;
        }else if (rpwd.equals("")){
            error=true;
        }else if (cuenta.equals("")){
            error=true;
        }
        if (error!=true){
            if(sac.buscarUsuario(nick)==null){                
                //Calcular el id_usuario
                sac.insertarUsuario(nombre, apellido, nick, pwd, direccion, tfno, Integer.parseInt(cuenta), provincia, municipio, email);
                mostrar(resp,"Ha sido registrado");
                return;
            }else{
                //ya existe
                mostrar(resp,"Ese nick ya esta");
                return;
            }
        }else{
            //esta en blanco algo.
            mostrar(resp,"Hay alguna casilla en blanco");
            return;
        }
    }
    
    private void mostrar(HttpServletResponse resp, String cadena){
        PrintWriter out;
        try {
            out = resp.getWriter();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("< meta content=\"text/html; charset=utf-8 />");
            out.println("<title>Logueo de Bar</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>"+cadena+"</h1>");
            out.println("</body>");
            out.println("</html>");
        } catch (IOException ex) {
            Logger.getLogger(NuevoBar.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
