/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;

/**
 *
 * @author appComanda
 */
public class lineaComanda {
    private int id_comanda;
    private int id_producto;
    private int id_bar;
    private int cantidad;
    private String descripcion; 
    public lineaComanda(int id_comanda, int id_producto, int cantidad, int id_bar, String descripcion){
        this.id_comanda=id_comanda;
        this.id_producto=id_producto;
        this.id_bar=id_bar;
        this.cantidad=cantidad;
        this.descripcion=descripcion;
    }

    public int getId_comanda() {
        return id_comanda;
    }

    public void setId_comanda(int id_comanda) {
        this.id_comanda = id_comanda;
    }

    public int getId_producto() {
        return id_producto;
    }

    public void setId_producto(int id_producto) {
        this.id_producto = id_producto;
    }

    public int getId_bar() {
        return id_bar;
    }

    public void setId_bar(int id_bar) {
        this.id_bar = id_bar;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    
}
