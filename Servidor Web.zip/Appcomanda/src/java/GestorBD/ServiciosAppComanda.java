/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestorBD;

import Objetos.Administrador;
import Objetos.Bar;
import Objetos.Camarero;
import Objetos.Comanda;
import Objetos.MasVendido;
import Objetos.Producto;
import Objetos.ProductoPrecio;
import Objetos.lineaComanda;
import Objetos.Oferta;
import Objetos.Usuario;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import sun.misc.BASE64Encoder;

/**
 *
 * @author appComanda
 */
public class ServiciosAppComanda {
//-------------------------------------------------------------BAR-------------------------------------------------------------------------------------
    public String insertarBar(int id, String nombre, String direccion ,int telefono, String correo,double latitud, double longitud, String provincia, String municipio, String contraseña){
        String exito="false";
        Connection con = null;
        String sql ="INSERT INTO `bar`(`Id_Bar`, `Nombre`, `Direccion`, `Telefono`, `Longitud`, `Latitud`, `Provincia`, `Municipio`, `Correo`, `Contraseña`, `VersionInfoBar`,`VersionCarta`, `VersionOfertas`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement ps;    
        try {            
            con = ConexionDB.GetConnection();
            con.setAutoCommit(false);
            ps= con.prepareStatement(sql);            
            ps.setInt(1, id);
            ps.setString(2, nombre);
            ps.setString(3, direccion);
            ps.setInt(4, telefono);
            ps.setDouble(5, longitud);
            ps.setDouble(6, latitud);
            ps.setString(7, provincia);
            ps.setString(8, municipio);
            ps.setString(9, correo);
            ps.setString(10, contraseña);
            ps.setInt(11, '2');
            ps.setInt(12, '0');
            ps.setInt(13, '0');
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito="true";
        } catch (SQLException ex) {
            //exito="excepcion";
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            if (con!=null) try {
                    con.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            if (con !=null) try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
    public boolean modificarBar(String nombre, String direccion ,int telefono, String correo,double latitud, double longitud, String provincia, String municipio, String contraseña,String nombre2){
        boolean exito=false;
        Connection con = null;
        //update empleado set salario=(1+?)/(100)
        
        String sql ="Update `bar` set `Nombre`=?, `Direccion`=?, `Telefono`=?, `Longitud`=?, `Latitud`=?, `Provincia`=?, `Municipio`=?, `Correo`=?, `Contraseña`=? where Nombre like ? ";
        PreparedStatement ps;    
        try {
            con = ConexionDB.GetConnection();
            con.setAutoCommit(false);
            ps= con.prepareStatement(sql);
            ps.setString(1, nombre);
            ps.setString(2, direccion);
            ps.setInt(3, telefono);
            ps.setDouble(4, longitud);
            ps.setDouble(5, latitud);
            ps.setString(6, provincia);
            ps.setString(7, municipio);
            ps.setString(8, correo);
            ps.setString(9, contraseña);
            ps.setString(10, nombre2);
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito=true;
        } catch (SQLException ex) {
            //exito="excepcion";
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            if (con!=null) try {
                    con.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            if (con !=null) try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
    
    public List<Bar> listaBar(){
        List<Bar> lb = new Vector<Bar>();
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Bar b = null;
        
        con= ConexionDB.GetConnection();
        String sql = "SELECT `Id_Bar`,`Nombre` ,`Direccion`,`Telefono`, `Longitud`,`Latitud`,`Provincia`, `Municipio`,`Correo`, `Contraseña` FROM `bar` ";
        try {
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while (rs.next()){
                b = new Bar(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(9), rs.getDouble(5), rs.getDouble(6), rs.getString(7), rs.getString(8), rs.getString(10));
                lb.add(b);
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lb;
        }
    }
     
    public Bar buscarBar(String nombre){
        
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Bar b = null;        
        con= ConexionDB.GetConnection();        
        String sql = "SELECT `Id_Bar`,`Nombre` ,`Direccion`,`Telefono`, `Longitud`,`Latitud`,`Provincia`, `Municipio`,`Correo`, `Contraseña` FROM `bar` WHERE `Nombre`=? ";
        try {
            
            ps=con.prepareStatement(sql);
            ps.setString(1, nombre);
            rs=ps.executeQuery();
            if (rs.next()){
                b = new Bar(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(9), rs.getDouble(5), rs.getDouble(6), rs.getString(7), rs.getString(8), rs.getString(10));
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return b;
        }
    }
    
    public Bar buscarBar(int id_bar){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Bar b = null;
        
        con= ConexionDB.GetConnection();
        String sql = "SELECT `Id_Bar`,`Nombre` ,`Direccion`,`Telefono`, `Longitud`,`Latitud`,`Provincia`, `Municipio`,`Correo`, `Contraseña` FROM `bar` WHERE `Id_Bar`=? ";
        try {
            
            ps=con.prepareStatement(sql);
            ps.setInt(1, id_bar);
            rs=ps.executeQuery();
            if (rs.next()){
                b = new Bar(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(9), rs.getDouble(5), rs.getDouble(6), rs.getString(7), rs.getString(8), rs.getString(10));
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return b;
        }
    }
    
    public boolean borrarBar(int id){
        Connection con;
        boolean exito = false;
        PreparedStatement ps = null;
        ResultSet rs = null;
        con= ConexionDB.GetConnection();
        String sql ="DELETE FROM `bar` WHERE `Id_Bar` = ?";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            exito=true;
            ps.close();
            con.commit();            
        } catch (SQLException ex) {
            con.rollback();
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
    
    public String logueoBar(int id ){
        Connection con;
        String resultado = "";
        PreparedStatement ps = null;
        ResultSet rs = null;
        con= ConexionDB.GetConnection();
        String sql ="SELECT `Contraseña` FROM `bar` WHERE `Id_Bar`=?";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, id);
            rs=ps.executeQuery();
            if (rs.next()){               
                resultado = rs.getString(1);
            }
        } catch (SQLException ex) {
            con.rollback();
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return resultado;
        }
    }
    
    
//-----------------------------Producto--------------------------------------------------------------------------------
    
    public boolean insertarProducto(int id, String nombre,String categoria){
        boolean exito=false;
        Connection con = null;
        String sql ="INSERT INTO `producto`(`Id_Producto`, `Nombre`, `Categoria`) VALUES (?,?,?)";
        PreparedStatement ps;    
        try {
            con = ConexionDB.GetConnection();
            con.setAutoCommit(false);
            ps= con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.setString(2, nombre);
            ps.setString(3, categoria);
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito=true;
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            if (con!=null) try {
                    con.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            
            if (con !=null) try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
    public List<Producto> listaProducto(){
        List<Producto> lb = new Vector<Producto>();
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Producto p = null;
        
        con= ConexionDB.GetConnection();
        String sql = "SELECT `Id_Producto`,`Nombre`,`Categoria` FROM `producto`";
        try {
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while (rs.next()){
                p = new Producto(rs.getInt(1), rs.getString(2), rs.getString(3));
                lb.add(p);
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lb;
        }
    }
    
    public List<Producto> listaProducto(String nombre){
        List<Producto> lb = new Vector<Producto>();
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Producto p = null;
        
        con= ConexionDB.GetConnection();
        String sql = "SELECT `Id_Producto`,`Nombre`,`Categoria` FROM `producto` where nombre like '"+nombre+"%'";
        try {
            ps=con.prepareStatement(sql);
            
            //ps.setString(1, nombre);
            System.out.println("npmbre"+ sql);
            rs=ps.executeQuery();
            while (rs.next()){
                p = new Producto(rs.getInt(1), rs.getString(2), rs.getString(3));
                lb.add(p);
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lb;
        }
    }
    
    public Producto buscarProducto(int id){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Producto p = null;
        
        con= ConexionDB.GetConnection(); 
        String sql = "SELECT `Id_Producto`,`Nombre`,`Categoria` FROM `producto` WHERE `Id_Producto`=?";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, id);
            rs=ps.executeQuery();
            if (rs.next()){
                p = new Producto(rs.getInt(1), rs.getString(2), rs.getString(3));
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return p;
        }
    }
    
    public Producto buscarProducto(String nombre){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Producto p = null;
        
        con= ConexionDB.GetConnection(); 
        String sql = "SELECT `Id_Producto`,`Nombre`,`Categoria` FROM `producto` WHERE `Nombre`=?";
        try {
            ps=con.prepareStatement(sql);
            ps.setString(1, nombre);
            rs=ps.executeQuery();
            if (rs.next()){
                p = new Producto(rs.getInt(1), rs.getString(2), rs.getString(3));
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return p;
        }
    }        
    
//-----------------------------------------------------CAMARERO----------------------------------------
    public boolean insertarCamarero(int id, String nombre, String apellidos ,String contraseña, String nick ,int id_bar){
        boolean exito=false;
        Connection con = null;
        String sql ="INSERT INTO `camarero`(`Id_Camarero`, `Nombre`, `Apellidos`, `Contraseña`, `nick`, `Id_Bar`) VALUES (?,?,?,?,?,?)";
        PreparedStatement ps;    
        try {
            con = ConexionDB.GetConnection();
            con.setAutoCommit(false);
            ps= con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.setString(2, nombre);
            ps.setString(3, apellidos);
            ps.setString(4, contraseña);
            ps.setString(5, nick);
            ps.setInt(6, id_bar);
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito=true;
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            if (con!=null) try {
                    con.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            if (con !=null) try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
    
    public List<Camarero> listaCamareroBar(int id){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Camarero> lc = new Vector<Camarero>();
        Camarero c = null;
        
        con= ConexionDB.GetConnection(); 
        String sql = "SELECT `Id_Camarero`, `Nombre`, `Apellidos`, `Contraseña`, `nick`, `Id_Bar` FROM `camarero` WHERE `Id_Bar`=?";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, id);
            rs=ps.executeQuery();
            while (rs.next()){
                c = new Camarero(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(5),rs.getString(4),id);
                lc.add(c);
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lc;
        }
    }
    
    public Camarero buscarCamareroBar(int id_bar, String nick){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Camarero c = null;
        
        con= ConexionDB.GetConnection(); 
        String sql = "SELECT `Id_Camarero`, `Nombre`, `Apellidos`, `Contraseña`, `nick`, `Id_Bar` FROM `camarero` WHERE `Id_Bar`=? and `nick`= (?)";
        try {
            ps=con.prepareStatement(sql);
            System.out.println("eee"+ id_bar+nick);
            ps.setInt(1, id_bar);
            ps.setString(2, nick);
            rs=ps.executeQuery();
            while (rs.next()){
                c = new Camarero(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(5),rs.getString(4),id_bar);
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return c;
        }
    }
    
    public boolean modificarCamareroBar(int id, int id_bar, String nick, String nombre, String Apellidos, String Contraseña){
        Connection con;
        PreparedStatement ps = null;
        Boolean exito = false;
        
        con= ConexionDB.GetConnection(); 
        String sql = "UPDATE `camarero` SET `Id_Bar`=?,`Nombre`=?,`Apellidos`=?,`Contraseña`=?,`Id_Camarero`=?,`nick`=? WHERE `Id_Bar`=? and `Id_camarero`=?";    
        try {
            con = ConexionDB.GetConnection();
            con.setAutoCommit(false);
            ps= con.prepareStatement(sql);
            ps.setInt(1, id_bar);
            ps.setString(2, nombre);
            ps.setString(3, Apellidos);
            ps.setString(4, Contraseña);
            ps.setInt(5, id);
            ps.setString(6, nick);
            ps.setInt(7, id_bar);
            ps.setInt(8, id);
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito=true;
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
    
    public boolean borrarCamarero(int id){
        Connection con;
        boolean exito = false;
        PreparedStatement ps = null;
        ResultSet rs = null;
        con= ConexionDB.GetConnection();
        String sql ="DELETE FROM `camarero` WHERE `Id_Camarero`=?";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito=true;
        } catch (SQLException ex) {
            con.rollback();
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
    
//------------------------------------------COMANDA-----------------------------------------------------------------
    public boolean insertarComanda(int id, int id_bar, Date fecha ,int mesa, double coste ,int id_camarero){
        boolean exito=false;
        Connection con = null;
        String sql ="INSERT INTO `comanda`(`Id_Comanda`, `Id_Bar`, `Fecha`, `Mesa`, `Coste_Total`, `Id_Camarero`) VALUES (?,?,?,?,?,?)";
        PreparedStatement ps;    
        try {
            con = ConexionDB.GetConnection();
            con.setAutoCommit(false);
            ps= con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.setInt(2, id_bar);
            ps.setDate(3, fecha);
            ps.setInt(4, mesa);
            ps.setDouble(5, coste);
            ps.setInt(6, id_camarero);
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito=true;
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            if (con!=null) try {
                    con.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            if (con !=null) try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
    
    public List<Comanda> listaComandasCamarero(int id){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Comanda> lc = new Vector<Comanda>();
        Comanda c = null;
        
        con= ConexionDB.GetConnection(); 
        String sql = "SELECT `Id_Comanda`, `Id_Camarero`, `Id_Bar`, `Fecha`, `Mesa`, `Coste_Total`, `Nick` FROM `comanda` WHERE `Id_Camarero`=?";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, id);
            rs=ps.executeQuery();
            while (rs.next()){
                c = new Comanda(rs.getInt(1), rs.getInt(3) ,rs.getDate(4), rs.getInt(5), rs.getDouble(6),id,rs.getString(7));
                lc.add(c);
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lc;
        }
    }
    
    public List<Comanda> listaComandasBar(int id){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Comanda> lc = new Vector<Comanda>();
        Comanda c = null;
        
        con= ConexionDB.GetConnection(); 
        String sql = "SELECT `Id_Comanda`, `Id_Camarero`, `Id_Bar`, `Fecha`, `Mesa`, `Coste_Total`, `Nick` FROM `comanda` WHERE `Id_Bar`=?";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, id);
            rs=ps.executeQuery();
            while (rs.next()){
                c = new Comanda(rs.getInt(1), id ,rs.getDate(4), rs.getInt(5), rs.getDouble(6),rs.getInt(2),rs.getString(7));
                lc.add(c);
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lc;
        }
    }
    public boolean borrarComanda(int id){
        boolean exito=false;
        Connection con = null;
        String sql ="DELETE FROM `appcomanda`.`comanda` WHERE `comanda`.`Id_Comanda` = ?";
        PreparedStatement ps;    
        try {
            con = ConexionDB.GetConnection();
            con.setAutoCommit(false);
            ps= con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito=true;
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            if (con!=null) try {
                    con.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            if (con !=null) try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
    
//-----------------------------------------CARTA----------------------------------------------------------------------------------    
    public boolean insertarCarta(int id_bar, int id_producto ,double precio , String foto, String descripcion){
        boolean exito=false;
        Connection con = null;
        String sql ="INSERT INTO `carta`(`Id_Producto`, `Id_Bar`, `Precio`, `Foto`, `Descripcion`) VALUES (?,?,?,?,?)";
        PreparedStatement ps;    
        try {
            con = ConexionDB.GetConnection();
            con.setAutoCommit(false);
            ps= con.prepareStatement(sql);
            System.out.println("EEE+ "+foto+precio+id_bar+id_producto);
   
            ps.setInt(2, id_bar);
            ps.setInt(1, id_producto);
            ps.setDouble(3, precio);
            ps.setString(4, foto);
            ps.setString(4, descripcion);
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito=true;
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            if (con!=null) try {
                    con.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            if (con !=null) try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
    
    public boolean insertarCarta(int id_bar, int id_producto ,double precio , String ruta, String foto,String descripcion){
        boolean exito=false;
        Connection con = null;
        String sql ="INSERT INTO `carta`(`Id_Producto`, `Id_Bar`, `Precio`, `Foto`,`Foto2`,`Descripcion`) VALUES (?,?,?,?,?,?)";
        PreparedStatement ps;    
        
        
        //System.out.println("ver que soy "+ uri.toURL().);
        
        try {
            File file = new File(ruta);
            BufferedImage img = ImageIO.read(file);
            String imgstr;
            
            imgstr = encodeToString(img, "jpg");            
            con = ConexionDB.GetConnection();
            con.setAutoCommit(false);
            ps= con.prepareStatement(sql);
            
            ps.setInt(2, id_bar);
            ps.setInt(1, id_producto);
            ps.setDouble(3, precio);
            ps.setString(4, foto);
            ps.setString(5, imgstr);
            ps.setString(6, descripcion);
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito=true;
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            if (con!=null) try {
                    con.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            if (con !=null) try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
    
    private static String encodeToString(BufferedImage image, String type) {
        String imageString = null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();

        try {
            ImageIO.write(image, type, bos);
            byte[] imageBytes = bos.toByteArray();

            BASE64Encoder encoder = new BASE64Encoder();
            imageString = encoder.encode(imageBytes);

            bos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return imageString;
    }
    
    public List<ProductoPrecio> listaProductosBar(int id){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<ProductoPrecio> lpp = new Vector<ProductoPrecio>();
        ProductoPrecio pp = null;
        
        con= ConexionDB.GetConnection(); 
        String sql = "SELECT producto.Id_Producto, producto.Nombre, carta.Descripcion, producto.Categoria, carta.Precio, carta.Foto2 FROM `carta` as carta JOIN Producto as producto on carta.Id_Producto = producto.Id_Producto where carta.Id_Bar=?";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, id);
            rs=ps.executeQuery();
            while (rs.next()){
                
                pp = new ProductoPrecio(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getDouble(5), rs.getString(6));
                lpp.add(pp);
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lpp;
        }
    }
    
    
    public ProductoPrecio buscarProductoBar(int id, String producto){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        ProductoPrecio pp = null;
        
        con= ConexionDB.GetConnection(); 
        String sql = "SELECT producto.Id_Producto, producto.Nombre, carta.Descripcion, producto.Categoria, carta.Precio, carta.Foto2 FROM `carta` as carta JOIN Producto as producto on carta.Id_Producto = producto.Id_Producto where carta.Id_Bar=? and producto.Nombre=?";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.setString(2, producto);
            rs=ps.executeQuery();
            if (rs.next()){                
                pp = new ProductoPrecio(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getDouble(5), rs.getString(6));
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return pp;
        }
    }
    
    //Modificar la carta, tanto la foto como el precio
    public boolean modificarCartaBarPF(int id_prod, int id_bar, Double precio, String foto,String Descripcion){
        Connection con;
        PreparedStatement ps = null;
        Boolean exito = false;
        
        con= ConexionDB.GetConnection(); 
        String sql = "UPDATE `carta` SET `Precio`=?,`Foto2`=?,`Descripcion`=? WHERE `Id_Producto`=? and `Id_Bar`=?";    
        try {
            
            File file = new File(foto);
            BufferedImage img = ImageIO.read(file);
            String imgstr;
            imgstr = encodeToString(img, "jpg");            
            con = ConexionDB.GetConnection();
            con.setAutoCommit(false);
            ps= con.prepareStatement(sql);
            ps.setDouble(1, precio);
            ps.setString(2, imgstr);
            ps.setString(3, Descripcion);            
            ps.setInt(4, id_prod);
            ps.setInt(5,id_bar);
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito=true;
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
    
    public boolean modificarCartaBarP(int id_prod, int id_bar, Double precio, String descripcion){
        Connection con;
        PreparedStatement ps = null;
        Boolean exito = false;
        
        con= ConexionDB.GetConnection(); 
        String sql = "UPDATE `carta` SET `Precio`=?, `Descripcion`=? WHERE `Id_Producto`=? and `Id_Bar`=?";    
        try {                               
            con = ConexionDB.GetConnection();
            con.setAutoCommit(false);
            ps= con.prepareStatement(sql);
            ps.setDouble(1, precio);
            ps.setString(2,descripcion);
            ps.setInt(3, id_prod);
            ps.setInt(4,id_bar);          
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito=true;
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }

    public boolean borrarProductoCarta(int id_prod, int id_bar){
        boolean exito=false;
        Connection con = null;
        String sql ="DELETE FROM `appcomanda`.`carta` WHERE `Id_Producto`=? and `Id_Bar`=?";
        PreparedStatement ps;    
        try {
            System.out.println("claves   "+id_prod+"   "+ id_bar);
            con = ConexionDB.GetConnection();
            con.setAutoCommit(false);
            ps= con.prepareStatement(sql);
            ps.setInt(1, id_prod);
            ps.setInt(2, id_bar);
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito=true;
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            if (con!=null) try {
                    con.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            if (con !=null) try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
    
    public List<String> listaProductosCarta(int id_bar){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<String> ls = new Vector<String>();        
        
        con= ConexionDB.GetConnection(); 
        String sql = "SELECT p.`Nombre` FROM `producto` as p join Carta as c on p.Id_Producto=c.Id_Producto where c.Id_Bar=?";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, id_bar);
            rs=ps.executeQuery();
            while (rs.next()){
                ls.add(rs.getString(1));
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return ls;
        }
    }
    
//--------------------------------------------OFERTA--------------------------------------------------
    
    public boolean insertarOferta(int id_bar, int id_producto, double precio){
        boolean exito=false;
        Connection con = null;
        String sql ="INSERT INTO `oferta`(`Id_Bar`,`Id_Producto`, `Precio`,`Descripcion`) VALUES (?,?,?,?)";
        PreparedStatement ps;    
        try {
            con = ConexionDB.GetConnection();
            con.setAutoCommit(false);
            ps= con.prepareStatement(sql);
            ps.setInt(1, id_bar);
            ps.setInt(2, id_producto);
            ps.setDouble(3, precio);
            ps.setString(4, "");
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito=true;
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            if (con!=null) try {
                    con.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            if (con !=null) try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
    
    public boolean borrarOferta(int id_producto, int id_bar){
        boolean exito=false;
        Connection con = null;
        String sql ="DELETE FROM `oferta` WHERE `Id_Bar` = ? and `Id_Producto` = ? ";
        PreparedStatement ps;    
        try {
            con = ConexionDB.GetConnection();
            con.setAutoCommit(false);
            ps= con.prepareStatement(sql);
            ps.setInt(1, id_bar);
            ps.setInt(2, id_producto);
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito=true;
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            if (con!=null) try {
                    con.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            if (con !=null) try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
    
    public List<Oferta> listaOferta(int id_bar){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Oferta> lo = new Vector<Oferta>();
        Oferta o = null;
        con= ConexionDB.GetConnection(); 
        String sql = "SELECT `Id_Bar`,`Id_Producto`,`Precio` FROM `oferta` WHERE `Id_Bar`=?";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, id_bar);
            rs=ps.executeQuery();
            while (rs.next()){               
                o = new Oferta(rs.getInt(1),rs.getInt(2), rs.getDouble(3));
                lo.add(o);
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lo;
        }
    }
    
    
    
//-------------------------------LINEA COMANDA -------------------------------------------------------------
    
    public boolean insertarLineaComada(int id_comanda, int id_producto, int cantidad, int id_bar){
        boolean exito=false;
        Connection con = null;
        String sql ="INSERT INTO `linea_comanda`(`Id_Comanda`,`Id_Producto`, `Cantidad`,`Id_Bar`) VALUES (?,?,?,?)";
        PreparedStatement ps;    
        try {
            con = ConexionDB.GetConnection();
            con.setAutoCommit(false);
            ps= con.prepareStatement(sql);
            ps.setInt(1, id_comanda);
            ps.setInt(2, id_producto);
            ps.setDouble(3, cantidad);
            ps.setDouble(4, id_bar);
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito=true;
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            if (con!=null) try {
                    con.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            if (con !=null) try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
    
    public boolean borrarLineaComanda(int id_comanda, int id_producto,int id_bar){
        boolean exito=false;
        Connection con = null;
        String sql ="DELETE FROM `appcomanda`.`linea_comanda` WHERE `comanda`.`Id_Comanda` = ? and `comanda`.`Id_Producto` = ? and `comanda`.`Id_Bar` = ? ";
        PreparedStatement ps;    
        try {
            con = ConexionDB.GetConnection();
            con.setAutoCommit(false);
            ps= con.prepareStatement(sql);
            ps.setInt(1, id_comanda);
            ps.setInt(2, id_producto);
            ps.setInt(3, id_bar);
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito=true;
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            if (con!=null) try {
                    con.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            if (con !=null) try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }

    public List<lineaComanda> listaLineaComanda(){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<lineaComanda> lc = new Vector<lineaComanda>();
        lineaComanda c = null;
        
        con= ConexionDB.GetConnection(); 
        //String sql = "SELECT lc.Id_Comanda, lc.Id_Producto, lc.Cantidad ,lc.Id_Bar, p.Descripcion FROM linea_comanda as lc join Producto as p on lc.Id_Producto = p.Id_Producto Group by lc.Id_Comanda, lc.Id_Producto,lc.Id_Bar";
        String sql = "SELECT lc.Id_Comanda, lc.Id_Producto, lc.Cantidad ,lc.Id_Bar, p.Descripcion FROM linea_comanda as lc join Producto as p on lc.Id_Producto = p.Id_Producto";
        try {
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while (rs.next()){               
                c = new lineaComanda(rs.getInt(1),rs.getInt(2), rs.getInt(3), rs.getInt(4),rs.getString(5));
                lc.add(c);
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lc;
        }
    }    
    
    //-------------------------------------------Graficos----------------------------------------------
    
    public List<MasVendido> masVendidos(int Id_Bar){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List <MasVendido> lmv = new Vector<MasVendido>();
        MasVendido mv = null;
        con= ConexionDB.GetConnection(); 
        //String sql = "SELECT lc.Id_Comanda, lc.Id_Producto, lc.Cantidad ,lc.Id_Bar, p.Descripcion FROM linea_comanda as lc join Producto as p on lc.Id_Producto = p.Id_Producto Group by lc.Id_Comanda, lc.Id_Producto,lc.Id_Bar";
        String sql = "select count(lc.Id_producto), p.nombre from producto as p join linea_comanda as lc on p.Id_producto=lc.Id_producto where lc.Id_Bar = ? and p.Categoria<> 'B' group by lc.Id_Producto order by count(lc.Id_producto) desc limit 10";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, Id_Bar);
            rs=ps.executeQuery();
            while (rs.next()){       
                lmv.add(new MasVendido(rs.getInt(1), rs.getString(2)));                                
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lmv;
        }
    }
    
    public List<MasVendido> Bebidas(int Id_Bar){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List <MasVendido> lmv = new Vector<MasVendido>();
        MasVendido mv = null;
        con= ConexionDB.GetConnection(); 
        //String sql = "SELECT lc.Id_Comanda, lc.Id_Producto, lc.Cantidad ,lc.Id_Bar, p.Descripcion FROM linea_comanda as lc join Producto as p on lc.Id_Producto = p.Id_Producto Group by lc.Id_Comanda, lc.Id_Producto,lc.Id_Bar";
        String sql = "select count(lc.Id_producto), p.nombre from producto as p join linea_comanda as lc on p.Id_producto=lc.Id_producto where lc.Id_Bar = ? and p.Categoria = 'B' group by lc.Id_Producto order by count(lc.Id_producto) desc limit 10";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, Id_Bar);
            rs=ps.executeQuery();
            while (rs.next()){       
                lmv.add(new MasVendido(rs.getInt(1), rs.getString(2)));                                
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lmv;
        }
    }
    
    public List<MasVendido> diasVentas(int Id_Bar){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List <MasVendido> lmv = new Vector<MasVendido>();
        MasVendido mv = null;
        con= ConexionDB.GetConnection(); 
        //String sql = "SELECT lc.Id_Comanda, lc.Id_Producto, lc.Cantidad ,lc.Id_Bar, p.Descripcion FROM linea_comanda as lc join Producto as p on lc.Id_Producto = p.Id_Producto Group by lc.Id_Comanda, lc.Id_Producto,lc.Id_Bar";
        //String sql = "select dayname(fecha) as dia, count(lp.Id_comanda) as cantidad from comanda as c join linea_comanda as lp on c.Id_comanda=lp.Id_Comanda where c.Id_bar=? group by dia order by dia desc";
        String sql ="SELECT CONCAT(ELT(WEEKDAY(Fecha) + 1, 'Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado', 'Domingo')) AS dia, count(lp.Id_comanda) as cantidad FROM  Comanda as c join linea_comanda as lp on c.Id_comanda=lp.Id_Comanda where c.Id_bar=? group by dia order by cantidad asc";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, Id_Bar);
            rs=ps.executeQuery();
            while (rs.next()){       
                lmv.add(new MasVendido(rs.getInt(2), rs.getString(1)));                                
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lmv;
        }
    }
    
    public List<MasVendido> diasComandas(){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List <MasVendido> lmv = new Vector<MasVendido>();
        MasVendido mv = null;
        con= ConexionDB.GetConnection(); 
        String sql ="SELECT Fecha, count(*) FROM comanda group by Fecha";
        try {
            ps=con.prepareStatement(sql);            
            rs=ps.executeQuery();
            while (rs.next()){       
                lmv.add(new MasVendido(rs.getInt(2),rs.getDate(1).toString()));                                
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lmv;
        }
    }
    
    public List<MasVendido> rankinBares(){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List <MasVendido> lmv = new Vector<MasVendido>();
        MasVendido mv = null;
        con= ConexionDB.GetConnection(); 
        String sql ="SELECT b.nombre,count(c.Id_comanda) FROM comanda as c join bar as b on c.Id_bar=b.Id_bar group by c.Id_bar order by count(c.Id_comanda) desc limit 10";
        try {
            ps=con.prepareStatement(sql);            
            rs=ps.executeQuery();
            while (rs.next()){       
                lmv.add(new MasVendido(rs.getInt(2),rs.getString(1)));                                
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lmv;
        }
    }
    
    public List<MasVendido> rankinUsuarios(){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List <MasVendido> lmv = new Vector<MasVendido>();
        MasVendido mv = null;
        con= ConexionDB.GetConnection(); 
        String sql ="SELECT Nick, count(Id_Comanda) FROM `comanda` where Nick <>'' group by Nick order by count(Nick) desc limit 10";
        try {
            ps=con.prepareStatement(sql);            
            rs=ps.executeQuery();
            while (rs.next()){       
                lmv.add(new MasVendido(rs.getInt(2),rs.getString(1)));                                
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lmv;
        }
    }
    
    //--------------------------------------------------USUARIOS----------------------------------------------
    public Boolean insertarUsuario(String nombre,String apellidos,String nick, String contraseña ,String direccion ,String telefono, int cuenta, String provincia, String municipio, String correo){
        boolean exito=false;
        Connection con = null;
        String sql ="INSERT INTO `usuario`( `Nombre`, `Apellidos`, `Nick`, `Contraseña`, `Direccion`, `Telefono`, `Cuenta`, `Provincia`, `Municipio`, `Email`) VALUES (?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement ps;    
        try {
            con = ConexionDB.GetConnection();
            con.setAutoCommit(false);
            ps= con.prepareStatement(sql);            
            ps.setString(1, nombre);
            ps.setString(2, apellidos);
            ps.setString(3, nick);
            ps.setString(4, contraseña);
            ps.setString(5, direccion);
            ps.setString(6, telefono);
            ps.setInt(7, cuenta);
            ps.setString(8, provincia);
            ps.setString(9, municipio);
            ps.setString(10, correo);
            ps.executeUpdate();
            ps.close();
            con.commit();
            exito=true;
        } catch (SQLException ex) {
            //exito="excepcion";
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            if (con!=null) try {
                    con.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            if (con !=null) try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
    public Usuario buscarUsuario(String nick){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Usuario u = null;
        
        con= ConexionDB.GetConnection();
        String sql = "SELECT `Nombre`, `Apellidos`, `Nick`, `Contraseña`, `Direccion`, `Telefono`, `Cuenta`, `Provincia`, `Municipio`, `Email` FROM `usuario` WHERE `Nick`=? ";
        try {
            
            ps=con.prepareStatement(sql);
            ps.setString(1, nick);
            rs=ps.executeQuery();
            if (rs.next()){
                u = new Usuario(rs.getString(1), rs.getString(2), nick, rs.getString(4),rs.getString(5),rs.getString(6),rs.getInt(7),rs.getString(8),rs.getString(9),rs.getString(10));
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return u;
        }
    }
    
    public List<Comanda> listaComadasUsuario(String nick){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List <Comanda> lc = new Vector<Comanda>();
        Comanda c = null;
        con= ConexionDB.GetConnection();         
        String sql = "SELECT `Id_Comanda`, `Id_Camarero`, `Id_Bar`, `Fecha`, `Mesa`, `Coste_Total`, `Nick` FROM `comanda` WHERE `Nick`=?";
        try {
            ps=con.prepareStatement(sql);
            ps.setString(1, nick);            
            rs=ps.executeQuery();
            while (rs.next()){       
                c = new Comanda(rs.getInt(1),rs.getInt(3) ,rs.getDate(4), rs.getInt(5), rs.getDouble(6),rs.getInt(2),rs.getString(7));
                lc.add(c);
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }                        
            return lc;
        }
    }
    
    public List<MasVendido> masConsumidos(String nick){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List <MasVendido> lmv = new Vector<MasVendido>();
        MasVendido mv = null;
        con= ConexionDB.GetConnection();         
        String sql = "select count(c.Id_Bar), b.Nombre from comanda as c join bar as b on c.Id_bar=b.Id_Bar where c.nick =? group by c.Id_Bar order by count(c.Id_Bar) desc limit 10";
        try {
            ps=con.prepareStatement(sql);
            ps.setString(1, nick);
            rs=ps.executeQuery();
            while (rs.next()){       
                lmv.add(new MasVendido(rs.getInt(1), rs.getString(2)));                                
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lmv;
        }
    }
    
    public List<MasVendido> PlatosCliente(String nick){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List <MasVendido> lmv = new Vector<MasVendido>();        
        con= ConexionDB.GetConnection();         
        String sql = "select count(lc.Id_producto), p.nombre from producto as p join linea_comanda as lc on p.Id_producto=lc.Id_producto join comanda as c on c.Id_Comanda = lc.Id_comanda where c.Nick = ? and p.Categoria<> 'B' group by lc.Id_Producto order by count(lc.Id_producto) desc limit 10";
        try {
            ps=con.prepareStatement(sql);
            ps.setString(1, nick);
            rs=ps.executeQuery();
            while (rs.next()){       
                lmv.add(new MasVendido(rs.getInt(1), rs.getString(2)));                                
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lmv;
        }
    }
    
    
     public String Administrador(String nombre){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String cont = null;        
        con= ConexionDB.GetConnection();
        String sql = "SELECT `Contraseña` FROM `administrador` WHERE `Nombre`=? ";
        try {            
            ps=con.prepareStatement(sql);
            ps.setString(1, nombre);
            rs=ps.executeQuery();
            if (rs.next()){
                cont = rs.getString(1);
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return cont;
        }
    }
     
     
     public Administrador buscarAdministrador(String nombre){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Administrador ad = null;
        
        con= ConexionDB.GetConnection();
        String sql = "SELECT `Nombre`,`Contraseña` FROM `administrador` WHERE `Nombre`= ?";
        try {
            
            ps=con.prepareStatement(sql);
            ps.setString(1, nombre);
            rs=ps.executeQuery();
            if (rs.next()){
                ad = new Administrador(rs.getString(1), rs.getString(2));
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return ad;
        }
    }
     
     public List<MasVendido> UsoPlatos (){
        Connection con;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List <MasVendido> lmv = new Vector<MasVendido>();        
        con= ConexionDB.GetConnection();         
        String sql = "SELECT count(c.Id_producto) , p.Nombre FROM carta as c right join producto as p on c.Id_producto=p.Id_producto group by p.id_producto";
        try {
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while (rs.next()){       
                lmv.add(new MasVendido(rs.getInt(1), rs.getString(2)));                                
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return lmv;
        }
    }    
     
    public boolean borrarProducto(String nombre){
        Connection con;
        boolean exito = false;
        PreparedStatement ps = null;
        con= ConexionDB.GetConnection();
        Producto p = buscarProducto(nombre);
        String sql ="DELETE FROM `producto` WHERE `Id_Producto` = ?";
        
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, p.getId());            
            ps.executeUpdate();                                                
            exito=true; 
            con.commit();                         
            ps.close();            
        } catch (SQLException ex) {
            con.rollback();
            Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ServiciosAppComanda.class.getName()).log(Level.SEVERE, null, ex);
            }
            return exito;
        }
    }
}

