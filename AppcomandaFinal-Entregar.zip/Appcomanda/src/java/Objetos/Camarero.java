/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;

/**
 *
 * @author appComanda
 */
public class Camarero {

    
    private int id;
    private String nombre;
    private String apellidos;
    private String nick;
    private String contraseña;
    private int id_Bar;
    public Camarero(int id, String nombre, String apellidos, String nick, String contraseña, int id_Bar){
        this.id=id;
        this.nombre=nombre;
        this.apellidos=apellidos;
        this.nick=nick;
        this.contraseña=contraseña;
        this.id_Bar=id_Bar;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public int getId_Bar() {
        return id_Bar;
    }

    public void setId_Bar(int id_Bar) {
        this.id_Bar = id_Bar;
    }
    
    public void escribir(){
        System.out.println(id_Bar+id+nombre+apellidos+contraseña+"nick"+nick);
    }
}
