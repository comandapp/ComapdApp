/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;

/**
 *
 * @author appComanda
 */
public class Carta {
    private int id_carta;
    private int id_bar;
    private int id_producto;
    private double precio;
    private String foto;
    private String descripcion;
    
    public Carta(int id_carta, int id_bar, int id_producto, double precio, String foto, String descripcion){
        this.id_carta=id_carta;
        this.id_bar=id_bar;
        this.id_producto=id_producto;
        this.precio=precio;        
        this.foto=foto;
        this.descripcion= descripcion;                
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }   
    
    public int getId_carta() {
        return id_carta;
    }

    public void setId_carta(int id_carta) {
        this.id_carta = id_carta;
    }

    public int getId_bar() {
        return id_bar;
    }

    public void setId_bar(int id_bar) {
        this.id_bar = id_bar;
    }

    public int getId_producto() {
        return id_producto;
    }

    public void setId_producto(int id_producto) {
        this.id_producto = id_producto;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }
    
}
