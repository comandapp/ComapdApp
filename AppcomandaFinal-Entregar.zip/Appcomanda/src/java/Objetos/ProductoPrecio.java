/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;

import java.io.File;
import java.sql.Blob;

/**
 *
 * @author appComanda
 */
public class ProductoPrecio {
    private int id;
    private String nombre;
    private String descripcion;
    private String categoria;
    private Double precio;
    private String foto;
    public ProductoPrecio(int id, String nombre,String descripcion, String categoria,Double precio, String foto){
        this.id=id;
        this.nombre=nombre;
        this.descripcion=descripcion;
        this.categoria=categoria;
        this.precio=precio;
        this.foto=foto;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }
    
    
}
