/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;

/**
 *
 * @author Jonatan
 */



public class Usuario {    
    private String nombre;
    private String apellidos;
    private String nick;
    private String contraseña;
    private String direccion;
    private String provincia;
    private String municipio;
    private String correo;
    private String telf;
    private int cuenta;
    public Usuario(String nombre, String apellidos, String nick, String contraseña, String direccion, String telf, int cuenta, String provincia, String municipio, String correo){        
        this.nombre=nombre;
        this.apellidos=apellidos;
        this.nick=nick;
        this.contraseña=contraseña;
        this.direccion=direccion;
        this.telf=telf;
        this.cuenta=cuenta;
        this.provincia=provincia;
        this.municipio=municipio;
        this.correo=correo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelf() {
        return telf;
    }

    public void setTelf(String telf) {
        this.telf = telf;
    }

    public int getCuenta() {
        return cuenta;
    }

    public void setCuenta(int cuenta) {
        this.cuenta = cuenta;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
}
