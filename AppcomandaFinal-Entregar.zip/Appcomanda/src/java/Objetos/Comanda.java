/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;

import java.sql.Date;
import java.text.DateFormat;

/**
 *
 * @author appComanda
 */
public class Comanda {
    private int id_comanda;
    private int id_bar;
    private Date fecha;
    private int mesa;
    private double coste;
    private int id_camarero;
    private String nick;
    public Comanda(int id,int id_bar, Date fecha,int Mesa, double coste, int id_camarero, String nick){
        this.id_comanda=id;
        this.id_bar=id_bar;
        this.fecha=fecha;
        this.mesa=mesa;
        this.coste=coste;
        this.id_camarero=id_camarero;
        this.nick=nick;
    }

    public int getId_comanda() {
        return id_comanda;
    }

    public void setId_comanda(int id_comanda) {
        this.id_comanda = id_comanda;
    }

    public int getId_bar() {
        return id_bar;
    }

    public void setId_bar(int id_bar) {
        this.id_bar = id_bar;
    }

    public String getFecha() {
        DateFormat df1 = DateFormat.getDateInstance(DateFormat.SHORT);
        String s1 = df1.format(fecha);
        return s1;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getMesa() {
        return mesa;
    }

    public void setMesa(int mesa) {
        this.mesa = mesa;
    }

    public double getCoste() {
        return coste;
    }

    public void setCoste(double coste) {
        this.coste = coste;
    }

    public int getId_camarero() {
        return id_camarero;
    }

    public void setId_camarero(int id_camarero) {
        this.id_camarero = id_camarero;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }
    
    
}
