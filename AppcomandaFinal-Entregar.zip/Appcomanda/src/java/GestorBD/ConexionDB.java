//
///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package GestorBD;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.SQLException;
//import java.util.logging.Level;
//import java.util.logging.Logger;
//
///**
// *
// * @author Jonatan
// */
//public class ConexionDB {
//    public static Connection GetConnection(){
//        Connection con = null;
//        try{
//            Class.forName("com.mysql.jdbc.Driver");
//            String servidor = "jdbc:mysql://193.146.250.82:3306/appcomanda";
//            String usuarioDB = "jona";
//            String contrasenaBD= "jona";
//            con= DriverManager.getConnection(servidor,usuarioDB,contrasenaBD);
//        }catch(ClassNotFoundException ex){
//            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
//        } catch (SQLException ex) {
//            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
//        }finally{
//            return con;
//        }
//    }
//}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GestorBD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Jonatan
 */
public class ConexionDB {
    public static Connection GetConnection(){
        Connection con = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            String servidor = "jdbc:mysql://localhost/appcomanda";
            String usuarioDB = "Jona";
            String contrasenaBD= "123456789";
            con= DriverManager.getConnection(servidor,usuarioDB,contrasenaBD);
        }catch(ClassNotFoundException ex){
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            return con;
        }
    }
}

