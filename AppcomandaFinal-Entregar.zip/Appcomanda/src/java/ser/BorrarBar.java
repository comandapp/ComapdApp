/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ser;

import GestorBD.ServiciosAppComanda;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Jonatan
 */
public class BorrarBar extends HttpServlet {
    private ServiciosAppComanda sac = new ServiciosAppComanda();
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        String idBar= req.getParameter("id");
        System.out.println("borrado"+ idBar);
        boolean borrado =sac.borrarBar(Integer.parseInt(idBar));        
        if (borrado){            
            resp.sendRedirect("ListadoBar.jsp");
            return;
        }else{
            mostrar(resp, "El producto no se ha borrado.");
            return;
        }
    }
    
    private void mostrar(HttpServletResponse resp, String cadena){
        PrintWriter out;
        try {
            out = resp.getWriter();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Logueo de Bar</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>"+cadena+"</h1>");
            out.println("</body>");
            out.println("</html>");
        } catch (IOException ex) {
            Logger.getLogger(NuevoBar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
