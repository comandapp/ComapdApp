/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ser;

import GestorBD.ServiciosAppComanda;
import Objetos.Bar;
import Objetos.Carta;
import Objetos.ProductoPrecio;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;

import java.io.File;
import java.util.List;
import java.util.Vector;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 *
 * @author Jonatan
 */
public class ModificarCarta extends HttpServlet {
    private ServiciosAppComanda sac = new ServiciosAppComanda();
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ModificarCarta</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ModificarCarta atproror" + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
            
            HttpSession sesion = req.getSession();
            Bar b = (Bar) sesion.getAttribute("bar");
            String producto = req.getParameter("producto");
            ProductoPrecio pp = sac.buscarProductoBar(b.getId(), producto);
            req.setAttribute("pp", pp);
            RequestDispatcher rd = req.getRequestDispatcher("ModCarta.jsp");
            sesion.setAttribute("ProductoPrecio", pp);
            rd.forward(req, resp);

 
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
            req.setCharacterEncoding("UTF-8");
        try {
            HttpSession sesion = req.getSession();
            Bar b = (Bar) sesion.getAttribute("bar");
            
            String pathToImg = null;
            String fName = null;
            FileItemFactory factory = new DiskFileItemFactory();
            //((DiskFileItemFactory) factory).setRepository(new File("c:/tmp"));
            ServletFileUpload upload = new ServletFileUpload(factory);
            List<FileItem> items = upload.parseRequest(req);//aqui hay algo
            boolean error = false;
            boolean sinfoto= false;
            Carta car =null;
            String producto = null;
            String descripcion= null;
            double pvp=0;
            FileItem fich = null;
// lectura de parámetros
            for (FileItem item : items) {
                String campoN = item.getFieldName(); // Nombre del párametro
                if (item.isFormField()) { // parámetro normal
                    if (campoN.equals("producto")) {
                        producto = item.getString("UTF-8");
                        System.out.println("producto");
                    } else if (campoN.equals("precio")) {
                        pvp = Double.parseDouble(item.getString("UTF-8"));
                        System.out.println("precio");
                    }
                    else if (campoN.equals("descripcion")) {
                        descripcion = item.getString("UTF-8");
                    }
                }else if (campoN.equals("foto") && item.getName() != null &&
                            item.getName().trim().length() > 0) {
                        fich = item;
                    }
                
            }
            List<String> lv = new Vector<String>();
            if(producto.equals("")){
                error=true;
            }else if (pvp<0){
                error=true;
            }else if(fich==null){
                sinfoto= true;
                System.out.println("fdf");
            }else{
                String mime = fich.getContentType();
                fName = fich.getName(); // Nombre del fichero (ojo con IE)
                long ocupa = fich.getSize();
                boolean memo = fich.isInMemory();
                pathToImg = req.getServletContext().getRealPath("/")+"img/";
                fich.write(new File(pathToImg + "/" + fName)); // (ojo con IE). Fallará
            }
            if (!error){
                if (sinfoto){
                    //No hay foto pero nos han modificado el precio.
                    sac.modificarCartaBarP(sac.buscarProducto(producto).getId(), b.getId(), pvp, descripcion);
                    mostrar(resp, "El producto de la carta ha sido modificado correctamente");
                    return;
                }else{
                    //nos han modificado la foto y puede que el precio.
                    sac.modificarCartaBarPF(sac.buscarProducto(producto).getId(), b.getId(), pvp, req.getServletContext().getRealPath("/")+"img/"+fName, descripcion);
                    mostrar(resp, "El producto de la carta ha sido modificado correctamente");
                    return;
                }
            }else{
                mostrar(resp, "El campo precio es vacio o inferior a 0");
                return;
            }                              
        } catch (FileUploadException ex) {
            Logger.getLogger(AddCarta.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(AddCarta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void mostrar(HttpServletResponse resp, String cadena){
        PrintWriter out;
        try {
            out = resp.getWriter();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("< meta content=\"text/html; charset=utf-8 />");
            out.println("<title>Logueo de Bar</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>"+cadena+"</h1>");
            out.println("</body>");
            out.println("</html>");
        } catch (IOException ex) {
            Logger.getLogger(NuevoBar.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    
    
}
