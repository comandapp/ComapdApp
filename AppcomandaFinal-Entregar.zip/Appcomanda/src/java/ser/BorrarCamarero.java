/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ser;

import GestorBD.ServiciosAppComanda;
import Objetos.Bar;
import Objetos.Camarero;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Jonatan
 */
public class BorrarCamarero extends HttpServlet {

    private ServiciosAppComanda sac = new ServiciosAppComanda();

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
            HttpSession sesion = req.getSession();
            Bar b = (Bar) sesion.getAttribute("bar");    
            String nick = req.getParameter("camarero");
            Camarero c = sac.buscarCamareroBar(b.getId(), nick);
            sesion.setAttribute("camarero", c);
            req.setAttribute("c", c);
            RequestDispatcher rd = req.getRequestDispatcher("BorCamarero.jsp");
            rd.forward(req, resp);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
            HttpSession sesion = req.getSession();
            Camarero c = (Camarero) sesion.getAttribute("camarero");
            sac.borrarCamarero(c.getId());
            mostrar(resp,"El camarero ha sido borrado");
            return;
    }

    private void mostrar(HttpServletResponse resp, String cadena){
        PrintWriter out;
        try {
            out = resp.getWriter();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Logueo de Bar</title>");            
            out.println("< meta content=\"text/html; charset=utf-8 />");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>"+cadena+"</h1>");
            out.println("</body>");
            out.println("</html>");
        } catch (IOException ex) {
            Logger.getLogger(NuevoBar.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

}
