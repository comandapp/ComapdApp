/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ser;

import GestorBD.ServiciosAppComanda;
import Objetos.Bar;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Jonatan
 */
public class ModificarBar extends HttpServlet {
    private ServiciosAppComanda sac = new ServiciosAppComanda();
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ModificarBar</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ModificarBar at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String id = req.getParameter("id");
        String nombre = req.getParameter("nombre");
        String direccion = req.getParameter("direccion");
        String tfno = req.getParameter("tfno");
        String longitud = req.getParameter("longitud");
        String latitud = req.getParameter("latitud");
        String provincia = req.getParameter("provincia");
        String municipio = req.getParameter("municipio");
        String email = req.getParameter("email");
        String pwd = req.getParameter("pwd");
        String rpwd = req.getParameter("rpwd");
        //public Bar (int id, String nombre, String direccion ,int telefono, String correo,double latitud, double longitud, String provincia, String municipio,String contraseña){
        Boolean error= false;
        if (nombre.equals("")){
            error = true;
        }else if (direccion.equals("")){
            error=true;
        }else if (tfno.equals("")){
            error=true;
        }else if (longitud.equals("")){
            error=true;
        }else if (latitud.equals("")){
            error=true;
        }else if (provincia.equals("")){
            error=true;
        }else if (municipio.equals("")){
            error=true;
        }else if (email.equals("")){
            error=true;
        }else if (pwd.equals("")){
            error=true;
        }else if (rpwd.equals("")){
            error=true;
        }
        if (error!=true){
            if(pwd.equals(rpwd)){
                if (sac.buscarBar(nombre)==null){
                    HttpSession sesion = req.getSession();
                    Bar bar =(Bar) sesion.getAttribute("bar");
                    sac.modificarBar(nombre, direccion, Integer.parseInt(tfno), email, Double.parseDouble(latitud), Double.parseDouble(longitud), provincia, municipio, pwd,bar.getNombre());
                    mostrar(resp,"Todo correcto, usted ha modificado los datos.");
                    bar = sac.buscarBar(nombre);
                    sesion.setAttribute("bar", bar);
                    return;
                }else{
                    mostrar(resp,"Ya existe un bar con ese nombre.");
                    return;            
                }
            }else{
                mostrar(resp,"Las contraseñas no coiciden.");
                return;
            }
        }else{
            mostrar(resp,"Hay alguna casilla en blanco");
            return;
        }
    }
    
    private void mostrar(HttpServletResponse resp, String cadena){
        PrintWriter out;
        try {
            out = resp.getWriter();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("< meta content=\"text/html; charset=utf-8 />");
            out.println("<title>Logueo de Bar</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>"+cadena+"</h1>");
            out.println("</body>");
            out.println("</html>");
        } catch (IOException ex) {
            Logger.getLogger(NuevoBar.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

}
