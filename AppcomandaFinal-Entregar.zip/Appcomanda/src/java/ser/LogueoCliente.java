/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ser;

import GestorBD.ServiciosAppComanda;
import Objetos.Administrador;
import Objetos.Bar;
import Objetos.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Jonatan
 */
public class LogueoCliente extends HttpServlet {

    private ServiciosAppComanda sac = new ServiciosAppComanda();
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
            

        req.setCharacterEncoding("UTF-8");    
        String nombre = req.getParameter("nombre");
        String pwd = req.getParameter("pwd");
        HttpSession sesion = req.getSession();
        if (!nombre.equals("")){
            if(!pwd.equals("")) {
                if (sac.buscarBar(nombre)!=null){
                    if (sac.buscarBar(nombre).getContraseña().equals(pwd)){
                        Bar bar = sac.buscarBar(nombre);
                        sesion.setAttribute("bar", bar);  
                        resp.sendRedirect("Bar/EntradaBar");
                        return;
                    }else{                        
                        mostrar(resp,"La contraseña o el usuario son incorrectos");
                        return;
                    }
                }else if (sac.buscarUsuario(nombre)!= null){
                    if (sac.buscarUsuario(nombre).getContraseña().equals(pwd)){
                        Usuario us = sac.buscarUsuario(nombre);
                        sesion.setAttribute("usuario", us);
                        resp.sendRedirect("Usuario/EntradaUsuario.jsp");
                        return;
                    }else{
                        mostrar(resp,"La contraseña o el usuario son incorrectos");
                        return;
                    }
                }else if (sac.Administrador(nombre)!=null){
                        if (sac.Administrador(nombre).equals(pwd)){
                            Administrador ad = sac.buscarAdministrador(nombre);
                            sesion.setAttribute("admin", ad);                        
                            resp.sendRedirect("Admin/EntradaAdmin.jsp");
                            return;
                        }else{
                            mostrar(resp,"La contraseña o el usuario son incorrectos");
                            return; 
                        }
                }else{                    
                    mostrar(resp,"La contraseña o el usuario son incorrecto3s");
                    return; 
                }
            }else{ 
                mostrar(resp,"La contraseña esta vacia");
                return;
            }
        }else{
            mostrar(resp,"El nombre esta vacio");
            return;
        }
    }
    private void mostrar(HttpServletResponse resp, String cadena){
        PrintWriter out;
        try {
            out = resp.getWriter();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("< meta content=\"text/html; charset=utf-8 />");
            out.println("<title>Logueo de Bar</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>"+cadena+"</h1>");
            out.println("</body>");
            out.println("</html>");
        } catch (IOException ex) {
            Logger.getLogger(NuevoBar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }       
}

