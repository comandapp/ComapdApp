/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ser;

import GestorBD.ServiciosAppComanda;
import Objetos.Bar;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Jonatan
 */
public class AddOferta extends HttpServlet {

    private ServiciosAppComanda sac = new ServiciosAppComanda();
    
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        HttpSession sesion = req.getSession();
        Bar b = (Bar) sesion.getAttribute("bar");
        
        boolean error = false;
        String precio = req.getParameter("precio");
        String nombre = req.getParameter("nombre");
        
        if (nombre.equals("")){
            error= true;
        }else if (precio.equals("")){
            error = true;
        }
        if (!error){
            if (sac.buscarProducto(nombre)!=null){
                sac.insertarOferta(b.getId(), sac.buscarProducto(nombre).getId(), Double.parseDouble(precio));
                mostrar(resp,"La oferta ha sido añadida");
                return;
            }else{
            mostrar(resp,"El producto no existe");
            return;
            }
        }else{
            mostrar(resp,"Hay alguna casilla en blanco");
            return;
        }
    }
    private void mostrar(HttpServletResponse resp, String cadena){
        PrintWriter out;
        try {
            out = resp.getWriter();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Logueo de Bar</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>"+cadena+"</h1>");
            out.println("</body>");
            out.println("</html>");
        } catch (IOException ex) {
            Logger.getLogger(NuevoBar.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
